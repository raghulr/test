<?php
/*
 * Editor Thickbox popup
 */

// WP Header
echo $this->ajax_header();

// Trigger hook
$this->ajax_content_start();

?>



Test template

<?php

// WP footer
echo $this->ajax_footer();

?>